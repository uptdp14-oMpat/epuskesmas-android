plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.co.epuskesmas.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.co.epuskesmas.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
