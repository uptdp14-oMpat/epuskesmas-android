package id.co.epuskesmas.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var webView: WebView? = null
    private var progress: ProgressBar? = null
    private val registrationUrl = "https://epuskesmas.dinkes.semarangkota.go.id/antrian/daftar"
    private val officialHost = "epuskesmas.dinkes.semarangkota.go.id"
    private val blue = Color.rgb(20, 91, 145)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        webView?.destroy()
        webView = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 64, 40, 32)
            setBackgroundColor(Color.rgb(242, 248, 253))
        }
        val title = TextView(this).apply {
            text = "e-Puskesmas\nNgemplak Simongan"
            textSize = 27f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Layanan pendaftaran antrean online"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 32)
        }
        val note = TextView(this).apply {
            text = "Pendaftaran dilakukan melalui sistem resmi e-Puskesmas Kota Semarang. Pastikan memilih Puskesmas Ngemplak Simongan apabila pilihan fasilitas tersedia."
            textSize = 15f
            setTextColor(Color.rgb(55, 70, 82))
            setPadding(20, 24, 20, 24)
            setBackgroundColor(Color.WHITE)
        }
        val register = Button(this).apply {
            text = "BUKA PENDAFTARAN ANTREAN"
            isAllCaps = false
            setOnClickListener { openRegistration() }
        }
        val info = TextView(this).apply {
            text = "Aplikasi pendamping. Bukan aplikasi resmi Dinas Kesehatan dan tidak menyimpan data medis."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 8)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(note)
        root.addView(register, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28 })
        root.addView(info)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openRegistration() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 4)
        }
        val back = Button(this).apply {
            text = "‹ Kembali"
            isAllCaps = false
            setOnClickListener { showHome() }
        }
        val refresh = Button(this).apply {
            text = "Muat ulang"
            isAllCaps = false
            setOnClickListener { webView?.reload() }
        }
        bar.addView(back)
        bar.addView(refresh)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress?.progress = newProgress
                    progress?.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    return if (uri.scheme == "https" && uri.host == officialHost) {
                        false
                    } else {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {
                            Toast.makeText(this@MainActivity, "Tautan tidak dapat dibuka", Toast.LENGTH_SHORT).show()
                        }
                        true
                    }
                }
            }
            loadUrl(registrationUrl)
        }
        root.addView(bar)
        root.addView(progress)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        val current = webView
        if (current != null && current.canGoBack()) current.goBack() else showHome()
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
