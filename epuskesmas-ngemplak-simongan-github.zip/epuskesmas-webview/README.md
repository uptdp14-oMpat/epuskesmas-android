# e-Puskesmas Ngemplak Simongan (starter)

A small Android WebView companion app for the public Semarang e-Puskesmas registration page.

## Build APK with GitHub Actions (phone-friendly)
1. Create a **private** GitHub repository.
2. Upload the contents of this folder to the repository root (keep `.github/workflows/build-apk.yml`).
3. Push to the `main` branch, or open **Actions → Build Android APK → Run workflow**.
4. Open the completed workflow run and download the `epuskesmas-ngemplak-simongan-debug` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on an Android device.

## Build locally
Requires JDK 17, Android SDK platform 35/build-tools 35.0.0, and Gradle 8.9:

```bash
gradle assembleDebug
```

## Important scope and limitations
- This starter opens the public registration website inside Android WebView.
- The app does **not** access SIMPUS directly, does not create its own queue, and does not store patient/medical data.
- The website may still ask the patient to choose a health center. This starter does not force a facility selection or hide other facilities.
- Only use official API access after written authorization and technical documentation from the responsible health center/Dinkes.
- The displayed name is a project label, not a claim that this is an official government application.
- The sample is not yet published or signed for Play Store release.
